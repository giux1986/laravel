welcome to laravel
name:<?php echo $post["name"]?>
